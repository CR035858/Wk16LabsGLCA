package com.gl.ccms.labwk16d03dem1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Labwk16d03dem1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
