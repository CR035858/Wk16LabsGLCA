package com.gl.ccms.labwk16d04dem1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Labwk16d04dem1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
