package com.gl.libms.labwk16d01dem1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Labwk16d01dem1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
